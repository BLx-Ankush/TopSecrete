# ALICE AI Assistant - Submission Package

## About
ALICE is an advanced voice-based AI assistant with vision, OCR, and Windows automation capabilities.

## Quick Start
1. Install Python 3.11+
2. cd Alice_code
3. python -m venv venv
4. venv\Scripts\activate
5. pip install -r requirements.txt
6. Create .env file with API keys
7. python ..\alice_trigger.py

## Features
- Voice AI (Hinglish)
- Vision and OCR (11 tools)
- System Automation (14 functions)
- WhatsApp Integration
- Persistent Memory

## Requirements
- Windows 10/11
- Python 3.11+
- Google Gemini API Key
- LiveKit credentials

## Developer
Ankush - March 2026
